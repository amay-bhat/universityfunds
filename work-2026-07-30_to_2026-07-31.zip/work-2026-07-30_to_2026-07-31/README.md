# Work bundle — last 24 hours

**Window:** 2026-07-30 14:09 PDT → 2026-07-31 14:09 PDT
**Repo:** dashboardProject (University Endowment Investing Explorer), branch `main`
**Commits:** 7 (`a2eb063` … `00a08ec`) — working tree was clean at bundle time, so everything below is committed.
**Files touched:** 50 · **Net:** +9,958 / −80 lines

## What's in this zip

| Path | What it is |
|---|---|
| `README.md` | This manifest |
| `COMMITS.txt` | Full commit log with per-commit file stats |
| `full-diff.patch` | One combined diff for the whole window (`git diff a2eb063^ HEAD`) |
| `commits/*.patch` | The 7 commits as individual `git format-patch` files, in order |
| `files/` | Every changed file at its final (HEAD) state, in original repo paths |

## The three threads of work

### 1. Conduct framework — governance/orchestration layer (commits 1–2)

Built and then adopted a decision-and-work framework so autonomous sessions
escalate judgment calls instead of stopping.

- **Decision plane** — `files/.claude/skills/escalate/` — two-phase blind ruling
  protocol, kernel (universal articles K1–K6, reserved powers, tier table,
  escalation floor), verbatim brief/HITL/log templates.
- **Work plane** — `files/.claude/skills/conduct/` — conductor loop, routing
  rubric, task-brief template.
- **Design doc** — `files/CONDUCT-DESIGN.html`
- **Phase A acceptance** — `files/conduct/GOLDEN-REPLAY.md` — golden replay of four
  previously logged proxy decisions passed 4/4, zero regressions.
- **Phase B acceptance** — a cold-start conductor produced the task-1.6 pilot plan
  and surfaced six skill defects (all fixed same-day).
- **Adoption** — human-signed 2026-07-30; kernel stamped v1.0.0. Record in
  `files/conduct/ADOPTION.md`; `CONSTITUTION.md` / `CLAUDE.md` / `TASKS.md` updated.
- **Rail change** — `endowment_returns.source_id` split into
  `return_source_id` + `market_value_source_id` so each figure cites the document
  that actually contains it. 44 rows migrated; validator enforces the pairing
  both ways. See `files/src/lib/db/schema.ts`, `files/scripts/lib/seed-validate.ts`.

### 2. Implementation plan + data curation — tasks 1.5 & 1.6 (commit 3)

The pilot run of the framework above: four parallel workers under the fragment
protocol, per-unit QC against independently re-fetched primary documents, one
serialized integration lane.

**The implementation plan and briefs:**
- `files/conduct/plans/1.6-plan.md` — the decomposition and lease plan
- `files/conduct/briefs/1.6/COMMON.md` — shared brief all workers received
- `files/conduct/briefs/1.6/{stanford,mit,princeton,harvard-returns}.md` — per-worker briefs

**Worker outputs (fragments — workers never write inside `data/`):**
- `files/conduct/fragments/1.6/*` — per-school JSON, sources, README sections, build logs

**Integrated result in `files/data/`:**
- **Princeton** — 104 allocation rows (FY2005–FY2018, FY2020–FY2023, actual, explicitly dated) + 24 return rows
- **MIT** — 42 allocation rows (FY2001/03/04 Pool A under the pool-basis proxy decision; FY2008 target + FY2013–15 actual from congressional inquiry responses) + complete 26-year returns verified by compounding against seven MIT-published windows
- **Stanford** — 26 market-value rows FY2000–FY2025 (Aug-31 fiscal year); allocations/returns are a documented Merged Pool gap with a congressional-response upgrade path
- **Harvard** — returns series now unbroken FY2000–FY2025 (closes task 1.5)

Validator 30/30; seeded to Neon in one transaction; re-seed idempotent; DB matches files (349/128/95/130).

### 3. Documentation — manual, quick card, structure snapshot (commits 4–7)

- `files/MANUAL.html` + `files/conduct/QUICKCARD.md` — operator manual and quick
  card, written from a five-way parallel repo audit in which every command was
  verified by execution.
- **Six corrections** the audit forced in `files/data/README.md`: Harvard returns
  wrongly described as holed; Princeton market-value coverage overstated (21 rows,
  not 24); two disagreeing inventory tables; "7 categories/series" where the code
  has 8; MIT FY2001/03/04 still marked referred-up after the ruling; pre-split
  citation shape.
- `files/TASKS.md` — Checkpoint A agenda corrected (said Harvard has 16 allocation
  years; files hold 14). `files/CLAUDE.md` — records Stanford's August fiscal year.
  `files/STATUS.html` — 27 → 30 validator rules, two → three scope questions.
- `files/STRUCTURE.{md,txt,pdf}` — annotated repo tree, reading order for new
  sessions, functional groupings, structural debts, regeneration commands.
  Two follow-up fixes: PDF was silently clipping 13 lines in portrait (now
  landscape at cpi=12, all 164 lines verified); and a self-referential sentence
  about box-drawing glyphs was mangling itself during conversion.

**Deliberately untouched:** `PRD.md`. Its coverage promise disagrees with reality
on purpose — that disagreement is the Checkpoint A question for the human.

## Reapplying this work elsewhere

```bash
git am commits/*.patch          # replay all 7 commits with messages intact
# or
git apply full-diff.patch       # apply the whole window as one uncommitted change
```
